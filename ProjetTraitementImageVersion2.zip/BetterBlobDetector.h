#ifndef BETTERBLOBDETECTOR_H
#define BETTERBLOBDETECTOR_H
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
    #include "opencv2/features2d/features2d.hpp"
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>

using namespace cv;
using namespace std;

class BetterBlobDetector : public SimpleBlobDetector
{

public:
    BetterBlobDetector(const SimpleBlobDetector::Params &parameters = SimpleBlobDetector::Params());
    const vector < vector<Point> > getContours();

protected:
    virtual void detectImpl( const Mat& image, vector<KeyPoint>& keypoints, const Mat& mask=Mat()) const;
    virtual void findBlobs(const Mat &image, const Mat &binaryImage, vector<Center> &centers, vector < vector<Point> >&contours) const;

};
#endif // BETTERBLOBDETECTOR_H
