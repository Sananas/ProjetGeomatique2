#include <QCoreApplication>
#include <traitementimage.h>
#include <percepunit.h>
#include <batiment.h>
/// Global variables



int main(int argc, char *argv[1]){

    Mat image = imread(argv[1]);
    if( !image.data )
    { return -1; }

    Mat Classif, Classif2, res;
    image.copyTo(Classif);
    image.copyTo(Classif2);

    TraitementImage PremierTraitement(&image);

    percepunit Classification(&image, &Classif);

    Batiment filter(&image);
    namedWindow("image", CV_WINDOW_NORMAL );
    imshow("image", image);


    waitKey(0);
    return 0;
}
