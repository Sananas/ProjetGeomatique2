#include "traitementimage.h"


TraitementImage::TraitementImage(Mat *image)
{
    src = *image;
    // Création de copies de l'image en entrée
    Mat ImageSource,findVegetation;
    src.copyTo(ImageSource);
    src.copyTo(findVegetation);
    /// 1. Detection de la Vegetation
    DetectionVegetation(findVegetation);
    findVegetation.copyTo(src);


    findVegetation = Erosion(findVegetation, 2);
    // ... (Etapes + pour la végétation)

    /// 2. Detection de la route
    pixelOfRoad(); // On trouve les pixels correspondant à la teinte de la route
    thinning(); // On lance la squeletisation
    srcRoad = Dilatation(srcRoad, 1);

    /// 3. Detection des contours de la route
    Mat RoadContour;
    srcRoad.copyTo(RoadContour);
    ObjectfindContour(RoadContour); // On obtient les contours de la route

    /// 4. Soustraction de la route et de la végétation
    SoustractionMatrice(ImageSource);
    ImageSource.copyTo(srcCopie);
    *image = ImageSource;

    /// 5. Detection des contours des bâtiments
    DetectionBatiment(ImageSource);


    /// Affichage des resutats
    //  affiche(ImageSource, "Image sans Vegetation et route");

    waitKey(0);
}

Mat TraitementImage::DetectionVegetation(Mat& image){

    Mat pixelOfVegetation, mask;
    cvtColor(src, pixelOfVegetation, CV_BGR2GRAY);
    threshold(pixelOfVegetation, pixelOfVegetation, 110, 160,1);
    pixelOfVegetation.copyTo(mask);
    Mat A;
    srcVeg = Mat::ones(mask.rows,mask.cols,mask.type());   // Creation d'une matrice vide de 1

    srcVeg=srcVeg*255; // On remplace la matrice par la value 255

    for(int j=0;j<srcVeg.rows;j++)
    {
        for (int i=0;i<srcVeg.cols;i++)
        {
            if(pixelOfVegetation.at<uchar>(j,i)==0) // Si pixel de l'image sont noir
                srcVeg.at<uchar>(j,i) = 0; // alors on met le pixel de la matrice vide en noir
            else
                srcVeg.at<uchar>(j,i) = 255; // sinon blanc
        }
    }

    srcVeg.convertTo(srcVeg, CV_8U);
    src.convertTo(src, CV_8U);
    Mat Vegetation = srcVeg ;
    Vegetation.copyTo(A);
  /*  for(int j=0;j<A.rows;j++)
    {
        for (int i=0;i<A.cols;i++)
        {
            if(A.at<uchar>(j,i)==255)
                A.at<uchar>(j,i) = 0;
            else
                A.at<uchar>(j,i) = 255;
        }
    }
*/
  //  A = Erosion(A,3);
    cv::Mat inputImg = src;


    cvtColor(Vegetation, Vegetation, CV_GRAY2RGB);
    image = src - Vegetation;
    return image;
}

void TraitementImage::FindBlobs(const Mat &binary, vector < vector<Point2i> > &blobs)
{
    blobs.clear();

    // Fill the label_image with the blobs
    // 0  - background
    // 1  - unlabelled foreground
    // 2+ - labelled foreground

    Mat label_image;
    binary.convertTo(label_image, CV_32SC1);

    int label_count = 2; // starts at 2 because 0,1 are used already

    for(int y=0; y < label_image.rows; y++) {
        int *row = (int*)label_image.ptr(y);
        for(int x=0; x < label_image.cols; x++) {
            if(row[x] != 1) {
                continue;
            }

            Rect rect;
            floodFill(label_image, Point(x,y), label_count, &rect, 0, 0, 4);

            std::vector <Point2i> blob;

            for(int i=rect.y; i < (rect.y+rect.height); i++)
            {
                int *row2 = (int*)label_image.ptr(i);

                for(int j=rect.x; j < (rect.x+rect.width); j++)
                {
                    if(row2[j] != label_count)
                    {
                        continue;
                    }

                    blob.push_back(Point2i(j,i));
                }
            }

            blobs.push_back(blob);

            label_count++;
        }
    }
}



Mat TraitementImage::SoustractionMatrice(Mat& imageSrc){

    imageSrc.convertTo(imageSrc, CV_8U);

    srcRoad.convertTo(srcRoad, CV_8U);

    srcVeg.convertTo(srcVeg, CV_8U);
    srcVeg = Erosion(srcVeg,3);
    srcVeg = Dilatation(srcVeg,3);

    srcRoad = Dilatation(srcRoad,14);
    cvtColor(srcVeg, srcVeg, CV_GRAY2RGB);
    cvtColor(srcRoad, srcRoad, CV_GRAY2RGB);
    imageSrc = imageSrc - srcVeg;
    imageSrc = imageSrc - srcRoad;

    return imageSrc;

}

vector <vector<Point> > TraitementImage::ObjectfindContour(Mat& imageFindContour){
    Mat canny_output;
    vector<vector<Point> > contours;
    vector<Vec4i> hierarchy;
    RNG rng(12345);

    /// Detect edges using canny
    Canny( imageFindContour, canny_output, 100, 100*2, 3 );

    /// Find contours
    findContours( canny_output, contours, hierarchy, CV_RETR_TREE,
                  CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );

    /// Draw contours
    Mat drawing = Mat::zeros( canny_output.size(), CV_8UC3 );

    for( int i = 0; i < contours.size(); i++ )
    {
        Scalar color = Scalar( rng.uniform(0, 255),
                               rng.uniform(0,255), rng.uniform(0,255) );
        drawContours( drawing, contours, i, color, 2, 8, hierarchy, 0,
                      Point() );
    }

    imageFindContour = drawing;

    return contours;

}

Mat TraitementImage::Erosion(Mat image, int valueOfErosion){

    erode(image,image, Mat(), Point(-1,-1),valueOfErosion,1,1);
    return image;
}

Mat TraitementImage::Dilatation(Mat image, int valueOfDilatation){

    dilate(image,image, Mat(), Point(-1,-1),valueOfDilatation,1,1);
    return image;
}

Mat TraitementImage::affiche(Mat& image, char* const title){
    namedWindow(title, CV_WINDOW_NORMAL );
    imshow(title, image);

    return src;
}

TraitementImage::~TraitementImage(){

}

Mat TraitementImage::thinningIteration(Mat& img, int iter){
    CV_Assert(img.channels() == 1);
    CV_Assert(img.depth() != sizeof(uchar));
    CV_Assert(img.rows > 3 && img.cols > 3);

    Mat marker = Mat::zeros(img.size(), CV_8UC1);

    int nRows = img.rows;
    int nCols = img.cols;

    if (img.isContinuous()) {
        nCols *= nRows;
        nRows = 1;
    }

    int x, y;
    uchar *pAbove;
    uchar *pCurr;
    uchar *pBelow;
    uchar *nw, *no, *ne;    // north (pAbove)
    uchar *we, *me, *ea;
    uchar *sw, *so, *se;    // south (pBelow)

    uchar *pDst;

    // initialize row pointers
    pAbove = NULL;
    pCurr  = img.ptr<uchar>(0);
    pBelow = img.ptr<uchar>(1);

    for (y = 1; y < img.rows-1; ++y) {
        // shift the rows up by one
        pAbove = pCurr;
        pCurr  = pBelow;
        pBelow = img.ptr<uchar>(y+1);

        pDst = marker.ptr<uchar>(y);

        // initialize col pointers
        no = &(pAbove[0]);
        ne = &(pAbove[1]);
        me = &(pCurr[0]);
        ea = &(pCurr[1]);
        so = &(pBelow[0]);
        se = &(pBelow[1]);

        for (x = 1; x < img.cols-1; ++x) {
            // shift col pointers left by one (scan left to right)
            nw = no;
            no = ne;
            ne = &(pAbove[x+1]);
            we = me;
            me = ea;
            ea = &(pCurr[x+1]);
            sw = so;
            so = se;
            se = &(pBelow[x+1]);

            int A  = (*no == 0 && *ne == 1) + (*ne == 0 && *ea == 1) +
                    (*ea == 0 && *se == 1) + (*se == 0 && *so == 1) +
                    (*so == 0 && *sw == 1) + (*sw == 0 && *we == 1) +
                    (*we == 0 && *nw == 1) + (*nw == 0 && *no == 1);
            int B  = *no + *ne + *ea + *se + *so + *sw + *we + *nw;
            int m1 = iter == 0 ? (*no * *ea * *so) : (*no * *ea * *we);
            int m2 = iter == 0 ? (*ea * *so * *we) : (*no * *so * *we);

            if (A == 1 && (B >= 2 && B <= 6) && m1 == 0 && m2 == 0)
                pDst[x] = 1;
        }
    }

    img &= ~marker;
    return img;

}

Mat TraitementImage::thinning(){
    Mat bw;
    threshold(srcRoad, bw, 10, 255, CV_THRESH_BINARY);

    bw = bw.clone();
    bw /= 255;         // convert to binary image

    Mat prev = Mat::zeros(bw.size(), CV_8UC1);
    Mat diff;

    do {
        thinningIteration(bw, 0);
        thinningIteration(bw, 1);
        absdiff(bw, prev, diff);
        bw.copyTo(prev);
    }
    while (countNonZero(diff) > 0);

    bw *= 255;
    srcRoad = bw;
    return srcRoad;

}

Mat TraitementImage::pixelOfRoad()
{
    Mat PixelRoad,image,channel[3], rouge, bleu, vert, RoadMask;
    src.copyTo(PixelRoad);
    PixelRoad = Erosion(PixelRoad, 2);
    PixelRoad = Dilatation(PixelRoad, 2);
    PixelRoad = Erosion(PixelRoad, 4);
    PixelRoad = Dilatation(PixelRoad, 5);

    PixelRoad.copyTo(image);
    split(image, channel);
    rouge = channel[2];
    bleu = channel[0];
    vert = channel[1];


    int minRouge = 105;
    int maxRouge = 150;

    int minBleu = 110;
    int maxBleu = 150;

    int minVert = 110;
    int maxVert = 150;

    int ChanBleu = 0;
    int ChanRouge = 0;
    int ChanVert = 0;


    rouge.copyTo(RoadMask);

    RoadMask.convertTo(RoadMask,CV_8U);
    for (int row = 0; row < RoadMask.rows; row++) {

        for (int col = 0; col < RoadMask.cols; col++) {

            ChanBleu=(int)channel[0].at<uchar>(row,col) ;
            ChanRouge=(int)channel[2].at<uchar>(row,col);
            ChanVert=(int)channel[1].at<uchar>(row,col);

            if (minBleu < ChanBleu
                    && maxBleu > ChanBleu
                    && minRouge < ChanRouge
                    && maxRouge > ChanRouge
                    && minVert < ChanVert
                    && maxVert > ChanVert )
            {
                RoadMask.at<uchar>(row,col) = 255;

            }
            else RoadMask.at<uchar>(row,col) = 0;

        }

    }
    RoadMask = Erosion(RoadMask, 7);
    RoadMask = Dilatation(RoadMask, 30);

    srcRoad = RoadMask;

    return RoadMask;

}

Mat TraitementImage::RemplaceValuePixel(Mat& image, int minRouge, int maxRouge, int minBleu, int maxBleu, int minVert, int maxVert)
{
    Mat StructureMask;

    blur(image, image, Size(3,3) );
    Mat channel[3],rouge;
    split(image, channel);
    rouge = channel[2];

    int ChanBleu = 0;
    int ChanRouge = 0;
    int ChanVert = 0;

    rouge.copyTo(StructureMask);

    StructureMask.convertTo(StructureMask,CV_8U);
    for (int row = 0; row < StructureMask.rows; row++) {

        for (int col = 0; col < StructureMask.cols; col++) {

            ChanBleu=(int)channel[0].at<uchar>(row,col) ;
            ChanRouge=(int)channel[2].at<uchar>(row,col);
            ChanVert=(int)channel[1].at<uchar>(row,col);

            if (minBleu < ChanBleu
                    && maxBleu > ChanBleu
                    && minRouge < ChanRouge
                    && maxRouge > ChanRouge
                    && minVert < ChanVert
                    && maxVert > ChanVert )
            {
                StructureMask.at<uchar>(row,col) = 255;

            }
            else StructureMask.at<uchar>(row,col) = 0;

        }

    }


    StructureMask.convertTo(StructureMask, CV_8U);
    cvtColor(StructureMask, StructureMask, CV_GRAY2RGB);

    srcCopie.convertTo(srcCopie, CV_8U);

    image = srcCopie - StructureMask;

    return image;

}

Mat TraitementImage::DetectionBatiment(Mat& image){

    Mat StructureMask;

    blur(image, image, Size(3,3) );
    RemplaceValuePixel(image, 100,140,60,150,100,150);
    RemplaceValuePixel(image, 100,140,60,150,100,150);
    RemplaceValuePixel(image, 50,70,0,60,12,120);
    RemplaceValuePixel(image, 105,120,100,121,70,90);
    RemplaceValuePixel(image, 50,120,50,121,0,90);
    RemplaceValuePixel(image, 0,120,0,121,0,90);



    return image;


}


